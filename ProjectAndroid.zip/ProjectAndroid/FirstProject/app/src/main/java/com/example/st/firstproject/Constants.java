package com.example.st.firstproject;

public class Constants {
    public static String[] PIZZA_TYPES = {
            "DODO",
            "Pizza_Fox",
            "Dominos",
            "Papa_John"
    };

    public static final String[] PIZZA_DESCRIPTION = {

            "Good pizza",
            "Pizza fox",
            "pizza niger",
            "Ok ok ok!!!"
    };

    private Constants(){}
}
